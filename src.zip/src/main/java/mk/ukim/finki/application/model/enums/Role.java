package mk.ukim.finki.application.model.enums;

public enum Role {
    ADMIN,
    USER
}
