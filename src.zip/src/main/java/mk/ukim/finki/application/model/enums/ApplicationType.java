package mk.ukim.finki.application.model.enums;

public enum ApplicationType {
    CREDITS_35_PLUS,
    COURSE_WITHOUT_PREREQUISITE,
    PAYMENT_INSTALLMENTS,
    FIRST_YEAR_GROUP_CHANGING,
    PROFESSOR_CHANGING,
    MAJOR_CHANGING
}
