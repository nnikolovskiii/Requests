package mk.ukim.finki.application.model.enums;

public enum MajorType {
    KN,
    PIT,
    SIIS
}
