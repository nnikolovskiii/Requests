package mk.ukim.finki.application.model.enums;

/**
 * The status of an individualApplication
 */
public enum RequestStatus {
    APPROVED,
    PENDING,
    CANCELED
}
